#include<iostream>
using namespace std;

int main()
{
  cout << "It's-a me, GCC!" << endl;
  return 0;
}
