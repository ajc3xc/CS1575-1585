export ASAN_SYMBOLIZER_PATH=`which llvm-symbolizer-3.9`
export ASAN_OPTIONS=symbolize=1
