#include"funcs.h"
#include"vector.h"
using namespace std;

int main() {
  Vector<int> v;
  add(2,2);
  return 0;
}