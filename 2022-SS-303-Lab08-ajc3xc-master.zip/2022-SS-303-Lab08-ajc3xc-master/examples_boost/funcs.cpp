#include"funcs.h"

int add(int x, int y) {
  return x + y;
}

void throw_exception() {
  throw runtime_error("EXCEPTION!!!!!");
}

