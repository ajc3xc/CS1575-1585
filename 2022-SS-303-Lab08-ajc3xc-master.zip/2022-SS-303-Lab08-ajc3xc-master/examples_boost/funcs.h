#ifndef FUNCS_H
#define FUNCS_H
#include<stdexcept>
using namespace std;

int add(int x, int y);
void throw_exception();

#endif
