#define CATCH_CONFIG_MAIN
#include "list.h"
#include "catch.hpp"
#include <stdexcept>
using namespace std;

//head and empty must be assumed to work, otherwise nothing can be tested

template class List<int>;

TEST_CASE("List elements", "[list]")
{
  SECTION("Default constructor works")
  {
    List<int> l;
    CHECK(l.empty() == true);
  }

  SECTION("Check prepend works")
  {
    List<int> l;

    l.prepend(10);
    CHECK(l.head()==10);
  }

  SECTION("Check append works")
  {
    List<int> l;

    CHECK_THROWS_AS(l.head(), out_of_range);
    l.append(10);

    CHECK(l.head()==10);

    l.append(20);
    l.append(30);

    CHECK(l.head()==10);
  }

  SECTION("Check tail works")
  {
    List<int> l;
    l.append(10);
    l.append(20);
    l.append(30);
    l.prepend(0);

    CHECK(l.tail().head()==10);
  }

  SECTION("Check pop works")
  {
    List<int> l;
    l.append(10);
    l.append(20);
    l.pop();
    CHECK(l.head()==20);

    l.pop();
    CHECK_THROWS_WITH(l.pop(), "empty list");
  }

  SECTION("Check length works")
  {
    List<int> l;
    CHECK(l.length()==0);

    l.append(10);
    l.append(20);
    l.append(30);
    l.append(40);
    l.prepend(0);
    CHECK(l.length()==5);

    l.pop();
    l.pop();
    l.pop();
    CHECK(l.length()==2);
  }

  SECTION("Check iterator works")
  {
    List<int> l;

    l.append(10);
    l.append(20);
    CHECK(l.iterator()->elem==10);
    CHECK(l.iterator()->next->elem==20);

    l.prepend(0);
    CHECK(l.iterator()->elem==0);
    CHECK(l.iterator()->next->elem==10);
  }

  SECTION("Check copy constructor works")
  {
    List<int> l;
    List<int> c1;
    //couldn't figure how to test a blank object passed for a copy constructor.

    for(int x = 0; x < 10; x++)
    {
      l.append((x+1)*10);
    }

    List<int> tCopy(l);
    CHECK(tCopy.head()==10);
  }
}
