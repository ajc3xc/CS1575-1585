Project B

3)

(a) If nohub or disown is not used, the jobs will automatically terminate

(b) disown can stop a job (command as is),
or remove it from a terminal to run even after logged out (-h)

(c) wait completes certain background processes before continuing on current processes

4)

exit: quits the terminal / shell, can show exit status

coproc: makes processes run asynchronously

type: where a command's location is

>>: append to a file

tr: translate characters (uppercase->lowercase, DOS text -> Unix text)

pr: make std input text split into printable pages

fmt: read text from std input, output formatted text to std output

||: if the command on left side doesn't work, execute the command on the right

chown: change who owns a file

kill: stop a process
