#include<iostream>
#include"vector.h"
using namespace std;

int main()
{
    Vector<char *> lines;
    char *buf = new char[100];
    unsigned int total = 0;

    int Continue = 0;
    int currentLine = 0;
    while(cin.getline(buf, 100) && (Continue==0))
    {
        lines.push_back(buf);
        buf = new char[100];

        // Calculate average line length
        unsigned int length = 0;
        for(unsigned int j = 0; lines[currentLine][j] != '\0'; j++)
        {
            length++;
        }
        total += length;
        currentLine++;
        cout << total / lines.length() << endl;
        if(lines.length() > 0) Continue = 1;
    }

    return 0;
}
