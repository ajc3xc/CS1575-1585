#include<iostream>
#include<string>

using std::cout;
using std::endl;
using std::cin;

int main() 
{
    // Write your program here.

    return 0;
}

