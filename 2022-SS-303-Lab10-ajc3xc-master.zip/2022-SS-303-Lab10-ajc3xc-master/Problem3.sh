#!/bin/bash
#"\-01\-"
grep "^[0-9][0-9][0-9][0-9]\-01" numbers.log | wc -l
