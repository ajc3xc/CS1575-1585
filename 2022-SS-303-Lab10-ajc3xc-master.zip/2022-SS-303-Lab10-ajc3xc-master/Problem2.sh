#!/bin/bash

sed -i s/"[aeiou]"//g story-plain.txt
