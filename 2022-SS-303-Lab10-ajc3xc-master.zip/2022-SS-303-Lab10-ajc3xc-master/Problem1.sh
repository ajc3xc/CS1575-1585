#!/bin/bash
grep -v "^#" story-plain.txt

grep -v "^\\s\{1,\}#" story-space.txt
